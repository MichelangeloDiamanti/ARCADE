/*
README

Medieval Town Exteriors
Lylek Games

Thank you for purchasing this asset!

This exterior design kit consists of many small parts to design your own medieval town.
Fourty six prefabs included, in the Assets/MedievalTownExteriors/Prefabs folder.

Demo scene is provided in the Scenes folder, Assets/MedievalTownExteriors/Scenes.

For support, please contact:
Email: support@lylekgames.com
Thank you.

*******************************************************************************************

Website
http://www.lylekgames.com/

Email
support@lylekgames.com
*/
