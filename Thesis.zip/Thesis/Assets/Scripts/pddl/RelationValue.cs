﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum RelationValue {
	TRUE = 1, 
	FALSE = 2, 
	//UNKNOWN, 
	PENDINGTRUE = 3, 
	PENDINGFALSE = 4
};